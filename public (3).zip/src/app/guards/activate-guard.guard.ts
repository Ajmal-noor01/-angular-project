import { CanActivateFn } from '@angular/router';

export const activateGuardGuard: CanActivateFn = (route, state) => {
  return true;
};
