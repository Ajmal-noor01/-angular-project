import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-cart',
  imports: [RouterLink, FormsModule, CommonModule],
  templateUrl: './cart.component.html',
  styleUrl: './cart.component.scss'
})
export class CartComponent {
  productCart: any;
  productCarts: any[] = [];
  totalPrice: number = 0
  productDataCart: any[] = []
  // quantity: number = 1
  price: number = 0;
  quantity: number = 1;
  subtotal: number = 0;


  ngOnInit() {

    // const productDataCart = localStorage.getItem("productDetailStore");
    // if (productDataCart) {
    //   this.productCart = JSON.parse(productDataCart);
    //   this.productCart.quantity = 1;
    //   this.productCart.subtotal = Number(this.productCart.price) * this.productCart.quantity;
    //   this.productCarts.push(this.productCart)

    //   // this.calculateTotalPrice();
    // }
    // let cartItems = localStorage.getItem("cartProducts")

    // this.productCart = JSON.parse(cartItem)
    // this.productCart.quantity = 1;
    // this.productCarts.push(this.productLists)

    //test code
    this.productCarts = JSON.parse(localStorage.getItem("cartProducts") || '[]').map((productCart: any) => ({
      ...productCart,
      quantity: productCart?.quantity || 1,
      subtotal: Number(productCart.price) * (productCart.quantity || 1),
    }));

    this.calculateTotalPrice();

  }
  // updateQuantity(product: any, quantity: number) {
  //   product.quantity = quantity;
  //   product.subtotal = Number(product.price) * quantity;
  // this.calculateTotalPrice();


  // }
  calculateTotalPrice() {
    this.totalPrice = this.productCarts.reduce((sum, item) => sum + item.subtotal, 0);
  }
  increaseCartNumber() {
    if (this.productCart.quantity < 10)
      console.log(this.productCart);

    this.productCart.quantity++
    this.productCart.subtotal = Number(this.productCart.price) * this.productCart.quantity;
    this.calculateTotalPrice();
    // this.productCarts.push(this.productCart)
    localStorage.setItem("cartProducts", JSON.stringify(this.productCarts));
    console.log("increased");


  }
  DecreaseCartNumber() {

    if (this.productCart.quantity > 0)
      this.productCart.quantity--
    this.productCart.subtotal = Number(this.productCart.price) * this.productCart.quantity;

    this.calculateTotalPrice();
    localStorage.setItem("cartProducts", JSON.stringify(this.productCarts));
    //test code
    // let cartProduct = this.productCarts.find((item) => item.id === product.id);
    // if (cartProduct && cartProduct.quantity > 1) { // Prevent going below 1
    //   cartProduct.quantity--;
    //   cartProduct.subtotal = Number(cartProduct.price) * cartProduct.quantity;
    //   this.calculateTotalPrice();
    //   localStorage.setItem("cartProducts", JSON.stringify(this.productCarts))

    // }

  }
}
